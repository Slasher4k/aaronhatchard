<?php


/*
 * Check if WooCommerce is active
 */
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    
    /**
 * Save the custom fields for shipping calculator.
 */
    function time_based_single_shipping_calculator_fields() {
	$address = isset( $_REQUEST['calc_shipping_address'] ) ? $_REQUEST['calc_shipping_address'] : '';
        $city = isset( $_REQUEST['calc_shipping_city'] ) ? $_REQUEST['calc_shipping_city'] : '';
        $state = isset( $_REQUEST['calc_shipping_state'] ) ? $_REQUEST['calc_shipping_state'] : '';
        $postcode = isset( $_REQUEST['calc_shipping_postcode'] ) ? $_REQUEST['calc_shipping_postcode'] : '';
	
        if ( $address ) {
             WC()->customer->set_shipping_address($address );	
	}
        
        if ( $city ) {            
             WC()->customer->set_shipping_city($city );	
	}
        
        if ( $state ) {            
            WC()->customer->set_shipping_state($state);
	}
        
        if ( $postcode ) {             
             WC()->customer->set_shipping_postcode($postcode);
	}
    }
    add_action( 'woocommerce_calculated_shipping', 'time_based_single_shipping_calculator_fields' );
 
    function time_based_single_shipping_method() {
        if ( ! class_exists( 'TimeBased_Single_Shipping_Method' ) ) {
            class TimeBased_Single_Shipping_Method extends WC_Shipping_Method {
                /**
                 * Constructor for your shipping class
                 *
                 * @access public
                 * @return void
                 */
                public function __construct( ) {
                    $this->id                 = 'time_based_single';                   
                    $this->method_title       = __( 'Time Based Shipping', 'time_based_single' );  
                    $this->method_description = __( 'Time Based Shipping Method', 'time_based_single' ); 
                  
                    $this->availability = 'including';
                    
                    // enable this shipping method for all specifically allowed countries in general settings
                    $this->countries = get_option( 'woocommerce_specific_allowed_countries');

                    $this->init();
 
                    $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';
                    $this->title = isset( $this->settings['title'] ) ? $this->settings['title'] : __( 'Time Based Shipping', 'time_based_single' );
                }
 
                /**
                 * Init your settings
                 *
                 * @access public
                 * @return void
                 */
                function init() {
                    // Load the settings API
                    $this->init_form_fields(); 
                    $this->init_settings(); // load instance settings
                   
 
                    // Save settings in admin if you have any defined
                    add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
                }
 
                /**
                 * Define settings field for this shipping
                 * @return void 
                 */
                function init_form_fields() { 
                    
                        $store_address = get_option( 'woocommerce_store_address');
                        $store_city = get_option( 'woocommerce_store_city');
                        $store_postcode = get_option( 'woocommerce_store_postcode');
                        $country_state = wc_get_base_location();
                        $store_state = $country_state['state'];
                        $store_country = $country_state['country'];

                        $store = $store_address .', '.$store_city.", ". $store_state.", ".$store_country.', '.$store_postcode;
                        
                        
                    // We will add our settings here : 
                    $this->form_fields = array( 
                        'enabled' => array(
                             'title' => __( 'Enable', 'time_based_single' ),
                             'type' => 'checkbox',
                             'description' => __( 'Enable this shipping.', 'time_based_single' ),
                             'default' => 'yes'
                             ),

                        'title' => array(
                           'title' => __( 'Title', 'time_based_single' ),
                             'type' => 'text',
                             'description' => __( 'Title to be display on site', 'time_based_single' ),
                             'default' => __( 'Time Based', 'time_based_single' )
                             ),
                        'origin' => array(
                           'title' => __( 'Origin', 'time_based_single' ),
                             'type' => 'text',
                             'description' => __( 'Calculate travel time from this location', 'time_based_single' ),
                             'default' => __( $store, 'time_based_single' )
                             ),
                        'api' => array(
                           'title' => __( 'Google Maps API Key', 'time_based_single' ),
                             'type' => 'text',
                             'description' => __( 'Google Maps API Key', 'time_based_single' ),
                             'default' => __( '<API KEY>', 'time_based_single' )
                             ),
                        'max_weight' => array(
                            'title' => __( 'Max Weight (kg)', 'time_based_single' ),
                              'type' => 'number',
                              'description' => __( 'Maximum allowed weight', 'time_based_single' ),
                              'default' => 100
                              ),
                        'time_interval' => array(
                            'title' => __( 'Time Interval', 'time_based_single' ),
                            'type'          => 'select',
                            'description'   =>  __( 'Time intervals to charge for', 'time_based_single' ),
                            'options'       => array(
                                '60'	=> __( 'Minute', 'time_based_single' ),
                                '300'          =>__('Five Minutes','time_based_single'),
                                '900'	=> __( 'Quarter Hour', 'time_based_single' ),
                                '1800'          => __( 'Half Hour', 'time_based_single' ),
                                '3600'          => __( 'Hour', 'time_based_single' )
                            ),
                            'default' => '60'
                            ),
                        'interval_price' => array(
                            'title' => __( 'Interval Price ($)', 'time_based_single' ),
                              'type' => 'number',
                              'description' => __( 'Amount charged per time interval', 'time_based_single' ),
                              'default' => 10
                              ),
                        'fixed_cost' => array(
                            'title' => __( 'Fixed Cost ($)', 'time_based_single' ),
                              'type' => 'number',
                              'description' => __( "Fixed amount included in shipping cost", 'time_based_single' ),
                              'default' => 0
                              )
                        );
                }
 
                /**
                 * This function is used to calculate the shipping cost. Within this function we can check for weights, dimensions and other parameters.
                 *
                 * @access public
                 * @param mixed $package
                 * @return void
                 */
                public function calculate_shipping( $package = array() ) {     
                    // We will add the cost, rate and logics in here
                    $weight = 0;
                    $cost = 0;
                                       
                    //write_log($package["destination"]);
                                        
                    // get customers full address 
                    $address = $package["destination"]["address"]; 
                    $city = $package["destination"]["city"];
                    $state = $package["destination"]["state"];        
                    $country = $package["destination"]["country"]; 
                    $postcode = $package["destination"]["postcode"]; 
                    
                    $destination = urlencode($address .', '.$city.", ". $state.", ".$country.', '.$postcode);
                    
                    // Get store address
                    error_log("Calc Information");
                    write_log($destination);
                    write_log($this->get_method_title());
                    write_log($this->settings);
                    
                    
                    if (WC()->session->get( 'store_origin', false ) == false) {
                        
                        $store_urlencode = urlencode($this->settings['origin']);
                        
                        WC()->session->set('store_origin', $store_urlencode );
                    }
                    
                    $origin = WC()->session->get( 'store_origin');                   
                                        
                    // google maps api key
                    $api_key= $this->settings['api'];

                   $url = 'https://maps.googleapis.com/maps/api/directions/json?origin='.$origin.'&destination='. $destination .'&departure_time=now&traffic_model=best_guess&key='.$api_key ;             
                    
                    
                    $theBody = json_decode(wp_remote_retrieve_body( wp_remote_get($url) ),true);
                    
                    $time_interval = (int) $this->settings['time_interval'];
                    $interval_price = (int) $this->settings['interval_price'];
                    $fixed_cost = (int) $this->settings['fixed_cost'];
                                                   
                    $seconds = $theBody['routes'][0]['legs'][0]['duration_in_traffic']['value'];
                    error_log($seconds);
                    
                    // Check if google return a travel time, if not don't add a rate
                    if(!is_numeric($seconds)|| $seconds < 0)
                    {                       

                        $message = sprintf( __( 'Sorry, %s Shipping cost could not calculated ', 'time_based_single' ), $this->title );

                        $messageType = "invalidTravelTime";

                        if( ! wc_has_notice( $message, $messageType ) ) {
                            wc_add_notice( $message, $messageType );
                        }
                        
                        return;
                    }
                    
                    $total_intervals = round($seconds / $time_interval) ;
                    
                    $cost = ($total_intervals * $interval_price) + $fixed_cost ;
                   
                    $rate = array(
                        'id' => $this->id,
                        'label' => $this->title,
                        'cost' => $cost
                    );

                    $this->add_rate( $rate );
                    
                }
            }
        }
    }
 
    add_action( 'woocommerce_shipping_init', 'time_based_single_shipping_method' );
 
    function add_time_based_single_shipping_method( $methods ) {
        $methods[''] = 'TimeBased_Single_Shipping_Method';
        return $methods;
    }
 
    add_filter( 'woocommerce_shipping_methods', 'add_time_based_single_shipping_method' );
    
    function time_based_validate_order( $posted )   {
        $packages = WC()->shipping->get_packages();
     
        $chosen_methods = WC()->session->get( 'chosen_shipping_methods' );

        if( is_array( $chosen_methods ) && in_array( 'time_based_single', $chosen_methods ) ) {

            foreach ( $packages as $i => $package ) {

                if ( $chosen_methods[ $i ] != "time_based_single" ) {

                    continue;

                }

                $TimeBased_Single_Shipping_Method = new TimeBased_Single_Shipping_Method();
                $weightLimit = (int) $TimeBased_Single_Shipping_Method->settings['max_weight'];
                
                $weight = 0;

                foreach ( $package['contents'] as $item_id => $values ) 
                { 
                    $_product = $values['data']; 
                    if( is_numeric($_product->get_weight())){
                        $weight = $weight + $_product->get_weight() * $values['quantity']; 
                    } 
                }

                $weight = wc_get_weight( $weight, 'kg' );

                if( $weight > $weightLimit ) {

                        $message = sprintf( __( 'Sorry, %d kg exceeds the maximum weight of %d kg for %s', 'time_based_single' ), $weight, $weightLimit, $TimeBased_Single_Shipping_Method->title );

                        $messageType = "error";

                        if( ! wc_has_notice( $message, $messageType ) ) {

                            wc_add_notice( $message, $messageType );

                        }
                }
            }       
        } 
              
    } 
    
 
    add_action( 'woocommerce_review_order_before_cart_contents', 'time_based_validate_order' , 10 );
    add_action( 'woocommerce_after_checkout_validation', 'time_based_validate_order' , 10 );
    
}

if ( ! function_exists('write_log')) {
   function write_log ( $log )  {
      if ( is_array( $log ) || is_object( $log ) ) {
         error_log( print_r( $log, true ) );
      } else {
         error_log( $log );
      }
   }
}
